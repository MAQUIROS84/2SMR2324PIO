# SERVICIOS_SR

Buenas tardes

Quiero que os apunteis todos en este fichero 

NOMBRE Y APELLIDO Y VUESTRO GIT
Álaro Gómez alvarobaroja
Alan Shelemen | gatoencerradoensucasa
Stefano Gonzalez
Guanyu Ji
Jose Alberto
Iván kutsenko (Belfegohr)
<<<<<<< HEAD


=======
>>>>>>> e382e751dd223fd975b619e83779ccb2b7f64038
UN SALUDO GUAPISIMO777



